package org.tensorflow.demo;
import android.content.res.AssetManager;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.util.Log;

import java.io.ByteArrayOutputStream;

/**
 * Created by apple on 7/26/17.
 */

public class RecordingThread {
    private static final String LOG_TAG = "RecordingThread";
    private final String MODEL_DIR = "file:///android_asset/graph.pb";
    private static final int SAMPLE_RATE = 16000;
    private static final boolean NEED_DEBUG = true;
    public byte[] mRecordResult;
    private boolean mShouldContinue;
    private Thread mThread;
    public SpeechCallback mCallback;

    private TensorFlowKeywordSpotting tensorFlowKeywordSpotting;
    public static interface SpeechCallback {
        public void onSuccess(byte[] result);
        public void onError(byte[] result);
    }

    public RecordingThread(AssetManager assetManager) {
        tensorFlowKeywordSpotting = new TensorFlowKeywordSpotting(assetManager,MODEL_DIR);
    }

    public boolean recording() {
        return mThread != null;
    }

    public void startRecording() {

        if (recording())
            return;

        mShouldContinue = true;
        mThread = new Thread(new Runnable() {
            @Override
            public void run() {
                record();
            }
        });
        mThread.start();
    }
    public void stopRecording(SpeechCallback callback) {
        if (!recording())
            return;
        mCallback = callback;
        mShouldContinue = false;
        mThread = null;
    }

    private void record() {
        if (NEED_DEBUG) {
            Log.v(LOG_TAG, "Start");
        }
        // read 1 sec each time
        int bufferSize = (int) (SAMPLE_RATE * 2);
        if (bufferSize == AudioRecord.ERROR || bufferSize == AudioRecord.ERROR_BAD_VALUE) {
            bufferSize = SAMPLE_RATE * 2;
        }
        byte[] audioBuffer = new byte[3600*2];
        AudioRecord record = new AudioRecord(MediaRecorder.AudioSource.DEFAULT,
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferSize);
        if (record.getState() != AudioRecord.STATE_INITIALIZED) {
            if (NEED_DEBUG) {
                Log.e(LOG_TAG, "Audio Record can't initialize!");
            }
            return;
        }
        record.startRecording();
        if (NEED_DEBUG) {
            Log.v(LOG_TAG, "Start recording");
        }
        ByteArrayOutputStream bout = new ByteArrayOutputStream();
        while (mShouldContinue) {
            int numberOfByte = record.read(audioBuffer, 0, audioBuffer.length);
            float floatValues[] = util.byte2float(audioBuffer);
            this.tensorFlowKeywordSpotting.feed(floatValues);
            boolean result = this.tensorFlowKeywordSpotting.classify();
            if(result)
                Log.e(LOG_TAG,"Trigger!!!!");

        }
        Log.e(LOG_TAG, "----- " + mRecordResult[0] + " " + mRecordResult[1]);

        record.stop();
        record.release();
        mCallback.onSuccess(mRecordResult);
        if (NEED_DEBUG) {
            Log.v(LOG_TAG, String.format("Recording stopped. Samples read: %d", mRecordResult.length));
        }

    }
}

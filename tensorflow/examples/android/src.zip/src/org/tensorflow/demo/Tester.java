package org.tensorflow.demo;

/**
 * Created by apple on 7/20/17.
 */

public abstract class Tester {
    public abstract byte[] startTesting();
    public abstract boolean stopTesting();
}
